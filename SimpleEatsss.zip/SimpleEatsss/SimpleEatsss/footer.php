
<div class="footer">

    <div class="box-container">

        <div class="foot-box">
            <h2>Quick Links</h2>
            <a href="index.php">Home</a>
            <a href="view_all_recipes.php">Recipes</a>
            <a href="about.php">About</a>
        </div>

        <div class="foot-box">
            <h2>Contact</h2>
            <a href="contactus.php">Contact Us</a>
            <a href="#">+80 000</a>
            <a href="#">service@simpleeats.com.sg</a>
            <a href="#">10 Dover Dr, Singapore 138683</a>
        </div>

        <div class="foot-box">
            <h2>Follow us</h2>
            <a href="https://www.facebook.com/">Facebook</a>
            <a href="https://twitter.com/i/flow/signup">Twitter</a>
            <a href="https://www.instagram.com/">Instagram</a>
        </div>

    </div>

    <div class="credit"> Copyright @ 2023 by Simply Eats </div>

</div>