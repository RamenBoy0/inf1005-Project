<html lang = "en">
    <head>
        <?php
        include "header_nav_footer.php"
        ?>
    </head>
    <body>
        <header>
        <?php
        include "navbar.php"
        ?>
        </header>
        
    <main class = "container">
        <hr>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <?php
        {
         echo "<h1> We will get back to you shortly!</h1>";
         echo "<h1>Thank you for for your feedback<br></h1>";
         echo "<a href='index.php' class = 'btn btn-success'>Home-page</a>";
        }
        ?>
    </main>
        <br>
        <br>
        <footer>
        <?php
        include "footer.php"
        ?>
        </footer>
        </body>
</html>