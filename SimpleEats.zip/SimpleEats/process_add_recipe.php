<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>FAQ</title>

        <!--Swiper Bundle is a JS library used to do the interactive slider-->
        <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />

        <!--Library used to generate the icons and fonts-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

        <!--jQuery-->
        <script defer
        src="https://code.jquery.com/jquery-3.4.1.min.js"
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
        crossorigin="anonymous">
        </script>

         <link rel="stylesheet" 
         href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
         integrity=
         "sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
         crossorigin="anonymous">

        <!--Bootstrap JS-->
        <script defer
        src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"
        integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm"
        crossorigin="anonymous">          
        </script>
        <script defer src="js/home.js"></script>
        <link rel="stylesheet" href="css/nav_footer.css">
        <link rel="stylesheet" href="css/add_recipe.css">

    </head>
 
    <body>
        <header>
             <?php
            include "navbar.php";
            ?>
        </header>
       
        <main class="container" id="add_recipe">
            <section>
            <?php           
            
            $rname = $errorMsg = "";
            $success = true;
            if (empty($_POST["rname"]))
            {
                $errorMsg .= "Recipe Name is required.<br>";
                $success = false;
            }
            else
            {
                $rname = sanitize_input($_POST["rname"]);
                // Additional check to make sure e-mail address is well-formed.
                if (!filter_var($rname, FILTER_DEFAULT))
                {
                $errorMsg .= "Invalid recipe name format.";
                $success = false;
                }
            }

            
            
            $upload = $errorupload = "";
            $success2 = true;
            if (empty($_POST["upload"]))
            {
                $errorupload .= "Upload is required.<br>";
                $success2 = false; 
            }
            else
            {
                $upload = sanitize_input($_POST["upload"]);
                // Additional check to make sure e-mail address is well-formed.
                if (!filter_var($upload, FILTER_DEFAULT))
                {
                $errorupload .= "Invalid upload format.";
                $success2 = false;
                }
            }
 
            
            
            $prep = $errorprep = "";
            $success3 = true;
            if (empty($_POST["prep"]))
            {
                $errorprep .= "Preparation time is required.<br>";
                $success3 = false;
            }
            else
            {
                $prep = sanitize_input($_POST["prep"]);
                // Additional check to make sure e-mail address is well-formed.
                if (!filter_var($prep, FILTER_DEFAULT))
                {
                $errorprep .= "Invalid preparation time format.";
                $success3 = false;
                }
            }
            
            $cook = $errorcook = "";
            $success4= true;
            if (empty($_POST["cook"]))
            {
                $errorcook .= "Cooking time is required.<br>";
                $success4 = false;
            }
            else
            {
                $cook = sanitize_input($_POST["cook"]);
                // Additional check to make sure e-mail address is well-formed.
                if (!filter_var($cook, FILTER_DEFAULT))
                {
                $errorcook .= "Invalid cooking time format.";
                $success4 = false;
                }
            }
            
            
            $serving = $errorserving = "";
            $success5= true;
            if (empty($_POST["serving"]))
            {
                $errorserving .= "Serving is required.<br>";
                $success5 = false;
            }
            else
            {
                $serving = sanitize_input($_POST["serving"]);
                // Additional check to make sure e-mail address is well-formed.
                if (!filter_var($serving, FILTER_DEFAULT))
                {
                $errorserving .= "Invalid serving format.";
                $success5 = false;
                }
            }
            
            $description = $errordescription = "";
            $success6 = true;
            if (empty($_POST["description"]))
            {
                $errordescription .= "Description is required.<br>";
                $success6 = false;
            }
            else
            {
                $description = sanitize_input($_POST["description"]);
                // Additional check to make sure e-mail address is well-formed.
                if (!filter_var($description, FILTER_DEFAULT))
                {
                $errordescription .= "Invalid description format.";
                $success6 = false;
                }
            }
            
            
            $ingredients = $erroringredients = "";
            $success7 = true;
            if (empty($_POST["ingredients"]))
            {
                $erroringredients .= "Ingredients is required.<br>";
                $success7 = false;
            }
            else
            {
                $ingredients = sanitize_input($_POST["ingredients"]);
                // Additional check to make sure e-mail address is well-formed.
                if (!filter_var($ingredients, FILTER_DEFAULT))
                {
                $erroringredients .= "Invalid ingredients format.";
                $success7 = false;
                }
            }
            
            
            $methods = $errormethods = "";
            $success8 = true;
            if (empty($_POST["methods"]))
            {
                $errormethods .= "Methods is required.<br>";
                $success8 = false;
            }
            else
            {
                $methods = sanitize_input($_POST["methods"]);
                // Additional check to make sure e-mail address is well-formed.
                if (!filter_var($methods, FILTER_DEFAULT))
                {
                $errormethods .= "Invalid methods format.";
                $success8 = false;
                }
            }
            
            

            if (!$success or !$success2 or !$success3 or !$success4 or !$success5 or !$success6 or !$success7 or !$success8){
                
                echo "<br>";
                echo "<br>";
                echo "<br>";
                echo "<h1>Oops!</h1>";
                echo "<h2>The following input errors were detected:</h2>";
                
                if (!$success){
                    echo "<p>" . $errorMsg . "</p>";
                }
                if (!$success2){
                    echo "<p>" . $errorupload . "</p>";
                }
                if (!$success3){
                    echo "<p>" . $errorprep . "</p>";
                }
                if (!$success4){
                    echo "<p>" . $errorcook . "</p>";
                }
                if (!$success5){
                    echo "<p>" . $errorserving . "</p>";
                }
                if (!$success6){
                    echo "<p>" . $errordescription . "</p>";
                }
                if (!$success7){
                    echo "<p>" . $erroringredients . "</p>";
                }
                if (!$success8){
                    echo "<p>" . $errormethods . "</p>";
                }
                
                $link = 'add_recipe.php';
                printf(' <a href="' .$link. '">
                <button style="background-color: red;border-color: white;" class="btn btn-primary">Return to Add Recipe</button>
                </a>');
                
            }
            else{
                
                echo "<br>";
                echo "<br>";
                echo "<br>";
                echo "<h1>You have successfully added a recipe.</h1>";
                echo "<br>";
                echo "<h2> Thank you. Recipe Name: " . $rname . ".</h2>";
                echo "<br>";
                
                $link = 'index.php';
                printf(' <a href="' .$link. '">
                <button style="background-color: green;border-color: white;" class="btn btn-primary">Home</button>
                </a>');
                
            }
            
            
            
            //Helper function that checks input for malicious or unwanted content.
            function sanitize_input($data)
            {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }
            ?>
            
            <br><br>
            </section>
        </main>
        <?php
        include "footer.php";
        ?>
    </body>


</html>
