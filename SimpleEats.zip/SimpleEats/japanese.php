<!doctype html>
<html lang="en">
    <head>
        <title>Chinese</title>
        <meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Simple Eats</title>

<!--Swiper Bundle is a JS library used to do the interactive slider-->
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />

<!--Library used to generate the icons and fonts-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

<!--jQuery-->
<script defer
src="https://code.jquery.com/jquery-3.4.1.min.js"
integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
crossorigin="anonymous">
</script>

 <link rel="stylesheet" 
 href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
 integrity=
 "sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
 crossorigin="anonymous">

<!--Bootstrap JS-->
<script defer
src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"
integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm"
crossorigin="anonymous">          
</script>
<script defer src="js/home.js"></script>
<link rel="stylesheet" href="css/nav_footer.css">
<link rel="stylesheet" href="css/cuisines.css">
    </head>
    <body>
        <header>
        <?php
            include "navbar.php";
        ?>  
        </header>
        
        <main class="cuisine-container">
            <h3>Japanese</h3>
            <div class="row">
                <article class="col-sm">
                    <h5>Chawanmushi</h5>
                    <figure>
                        <img src="images/chawanmushi.jpg" class="img-thumbnail" alt="Chawanmushi"/>
                    </figure>
                    <div class="button">
                        <a href="chawanmushi.php" >View More</a>
                    </div>
                </article>
                <article class="col-sm">
                    <h5>Pork Ramen</h5>
                    <figure>
                        <img src="images/porkramen.jpg" class="img-thumbnail" alt="Pork Ramen"/>
                    </figure>
                    <div class="button">
                        <a href="porkramen.php" >View More</a>
                    </div>
                </article>
                <article class="col-sm">
                    <h5>Teriyaki Chicken with Rice</h5>
                    <figure>
                        <img src="images/teriyakichicrice.jpg" class="img-thumbnail" alt="Teriyaki Chicken Rice"/>
                    </figure>
                    <div class="button">
                        <a href="teriyakichic.php" >View More</a>
                    </div>
                </article>
            </div>
        </main>

    </body>
    <?php
        include "footer.php";
    ?>  
</html>

