<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>FAQ</title>

        <!--Swiper Bundle is a JS library used to do the interactive slider-->
        <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />

        <!--Library used to generate the icons and fonts-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

        <!--jQuery-->
        <script defer
        src="https://code.jquery.com/jquery-3.4.1.min.js"
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
        crossorigin="anonymous">
        </script>

         <link rel="stylesheet" 
         href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
         integrity=
         "sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
         crossorigin="anonymous">

        <!--Bootstrap JS-->
        <script defer
        src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"
        integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm"
        crossorigin="anonymous">          
        </script>
        <script defer src="js/home.js"></script>
        <link rel="stylesheet" href="css/nav_footer.css">
        <link rel="stylesheet" href="css/add_recipe.css">


        <!-- Custom JS -->
        <script defer src="js/add_recipe.js"></script>


  
    </head>
 
    <body>
        <header>
             <?php
            include "navbar.php";
            ?>
        </header>
        
        <div class="container">
            <section>
                <br><br><br>
            <h1>Add Recipe</h1>
            <p>
                For more recipe  
                <a href="western.php">click here</a>.
            </p>
            <form action="process_add_recipe.php" method="post" novalidate>
                <div class="form-group">
                    <label for="fname">Name:</label>
                    <input class="form-control" maxlength="200" type="text" id="rname"
                        required name="rname" placeholder="Enter Name">
                </div>
                
                <div class="form-group">
                    <label for="upload">Upload Photo:</label>
                    <input type="file" id="myFile" name="upload"
                        required name="upload" placeholder="Upload Photo">
                </div>
                
                <div class="grid-container">
                    <div class="form-group">
                    <label for="prep">Prep time (minutes):</label>
                    <input class="form-control grid-item" type="number" id="prep" required name="prep" min="1" max="30" placeholder="Prep Time">
                    </div>

                    <div class="form-group">
                    <label for="prep">Cook time (minutes):</label>
                    <input class="form-control grid-item" type="number" id="cook" required name="cook" min="1" max="60" placeholder="Cook Time">
                    </div>

                    <div class="form-group">
                    <label for="serving">Serving:</label>
                    <input class="form-control grid-item" type="number" id="serving" required name="serving" min="1" max="5" placeholder="Serving">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="description">Description: </label>
                    <div class="rightside" id="counter"></div>
                    <textarea class="form-control" maxlength="500" type="text" id="description"
                        required name="description" placeholder="Enter Description"></textarea>
                </div>
              
                
                <div class="form-group">
                    <label for="ingredients">Ingredients:</label>
                    <div class="rightside" id="counter2"></div>
                    <textarea class="form-control" maxlength="1000" rows="5" type="text" id="ingredients"
                        required name="ingredients" placeholder="Enter Ingredients"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="methods">Methods:</label>
                    <div class="rightside" id="counter3"></div>
                    <textarea class="form-control" maxlength="5000" rows="10" type="text" id="methods"
                        required name="methods" placeholder="Enter Methods"></textarea>
                </div>
                

                <div class="form-group">
                    <button class="btn btn-primary" type="submit">Submit</button>
                </div>
            </form>
            </section>
        </div>
        <?php
        include "footer.php";
        ?>
    </body>


</html>
