        <div class="container">

            <section class="footer">

                <div class="box-container">

                    <div class="box">
                        <h3>Quick Links</h3>
                        <a href="#">Home</a>
                        <a href="#">Cuisines</a>
                        <a href="#">About</a>
                    </div>

                    <div class="box">
                        <h3>Contact</h3>
                        <a href="#">+80 000</a>
                        <a href="#">service@simpleeats.com.sg</a>
                        <a href="#">10 Bayfront Ave, L1-69, Singapore 016989</a>
                    </div>

                    <div class="box">
                        <h3>Follow us</h3>
                        <a href="https://www.facebook.com/">Facebook</a>
                        <a href="https://twitter.com/i/flow/signup">Twitter</a>
                        <a href="https://www.instagram.com/">Instagram</a>
                    </div>

                </div>

                <div class="credit"> Copyright @ 2023 by <span>Simple Eats</span> </div>

            </section>

        </div>