<?php
session_start();
?>
<section class="flex">

    <a href="index.php" class="logo"><i class="fas fa-utensils"></i>Simple Eats</a>

    <nav class="navbar">
        <a class="active" href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="#about">Cuisine</a>
        <a href="faq.php">FAQ</a>
        <?php if ($_SESSION["logged_in"] == true): ?>
        <a href="add_recipe.php">Add Recipe</a>
         <?php endif; ?>
        
    </nav>

    <div class="icons">
        <a class="fas fa-search" id="search-icon" aria-hidden = "true"></a>
        <?php if ($_SESSION["logged_in"] == true): ?>
        <a href="#" class="fas fa-heart" aria-hidden = "true"></a>
         <?php endif; ?>
        <a href="register.php" class="fa fa-registered" aria-hidden = "true"></a>
        <?php if (!isset($_SESSION["logged_in"])): ?>
        <a href="login.php" class="far fa-id-card"></a>
        <?php endif; ?> 
        <a href = "logout.php" class="fas fa-sign-out-alt"></a>
    </div>

</section>